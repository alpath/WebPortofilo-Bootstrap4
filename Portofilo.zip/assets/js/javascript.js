
// $(document).ready(function(){
//   $("#kl").click(function(){
//     $("#searc").fadeToggle();
//   });
// })
	// $("#show").click(function(){
	//   $("searc").show();
	// });
